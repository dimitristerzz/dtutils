import os
import requests
from dotenv import load_dotenv

def getInput(url):
    load_dotenv()

    headers = {
        "Cookie": f"session={os.getenv('SC')}",
    }

    return requests.get(url, headers=headers).text